from app import create_app
from app.database import db
from app.models import CustomUser, Student, Batch, Hostel, Room
from datetime import datetime
import random

app = create_app()

with app.app_context():
    db.create_all()

    # Add new hostels
    new_hostels = [
        Hostel(hostel_no='GA', hostel_name='Ganga', hostel_type='Boys', num_floors=4, capacity=400),
        Hostel(hostel_no='YA', hostel_name='Yamuna', hostel_type='Girls', num_floors=4, capacity=400)
    ]
    db.session.bulk_save_objects(new_hostels)
    db.session.commit()

    # Add rooms for new hostels
    new_rooms = []
    for floor in range(1, 5):  # 4 floors
        for room_no in range(1, 21):  # 20 rooms per floor
            new_rooms.append(Room(room_no=f'GA-{floor:02d}{room_no:02d}', floor=floor, hostel_no='GA', room_occupancy=2, current_occupancy=0))
            new_rooms.append(Room(room_no=f'YA-{floor:02d}{room_no:02d}', floor=floor, hostel_no='YA', room_occupancy=2, current_occupancy=0))
    db.session.bulk_save_objects(new_rooms)
    db.session.commit()

    # Fetch existing batches from the database
    batches = Batch.query.all()

    # Generate students for each batch
    